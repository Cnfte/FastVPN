#!/bin/bash
# 彩色定义
GREEN='\033[0;32m'; YELLOW='\033[1;33m'; BLUE='\033[1;36m'; RED='\033[0;31m'; NC='\033[0m'
VERSION="1.0.0"

# 检测服务器 IP
SERVER_IP=$(curl -s https://ifconfig.co)

clear
echo -e "${GREEN}=============================================${NC}"
echo -e "${GREEN}  多协议穿墙工具 一键部署脚本 v$VERSION      ${NC}"
echo -e "${YELLOW}  作者: cnfte | 支持协议：WG/VLESS/SS/SSR等${NC}"
echo -e "${BLUE}  GitHub: https://github.com/cnfte/geminiproxy${NC}"
echo -e "${GREEN}=============================================${NC}"

echo -e "请选择要安装的协议："
echo -e "${YELLOW} 1.${NC} 安装 WireGuard"
echo -e "${YELLOW} 2.${NC} 安装 VLESS（Reality）"
echo -e "${YELLOW} 3.${NC} 安装 Shadowsocks"
echo -e "${YELLOW} 4.${NC} 安装 ShadowsocksR"
echo -e "${YELLOW} 5.${NC} 安装 OpenVPN"
echo -e "${YELLOW} 6.${NC} 安装 Hysteria2"
echo -e "${YELLOW} 7.${NC} 安装 SOCKS5"
echo -e "${YELLOW} 8.${NC} 查看服务状态"
echo -e "${YELLOW} 9.${NC} 防火墙开关"
echo -e "${YELLOW} 0.${NC} 退出脚本"
echo -e "${GREEN}=============================================${NC}"
read -rp "请输入选项 [0-9]: " opt

case $opt in
  1) bash modules/wireguard.sh ;;
  2) bash modules/vless.sh ;;
  3) bash modules/shadowsocks.sh ;;
  4) bash modules/ssr.sh ;;
  5) bash modules/openvpn.sh ;;
  6) bash modules/hysteria2.sh ;;
  7) bash modules/socks5.sh ;;
  8) bash modules/monitor.sh ;;
  9) bash modules/firewall.sh ;;
  0) exit 0 ;;
  *) echo -e "${RED}无效选项，请重试${NC}" ;;
esac
