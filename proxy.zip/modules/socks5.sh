#!/bin/bash
function install_socks5() {
  echo "[+] 安装 Dante SOCKS5..."
  if [ -e /etc/debian_version ]; then apt update -y && apt install -y dante-server; else yum install -y dante-server; fi
  cat > /etc/danted.conf <<EOF
logoutput: /var/log/danted.log
internal: 0.0.0.0 port = 1080
external: $(ip route get 1 | awk '{print $5}')
method: none
user.privileged: root
user.notprivileged: nobody
client pass { from: 0.0.0.0/0 to: 0.0.0.0/0 log: connect error }
socks pass { from: 0.0.0.0/0 to: 0.0.0.0/0 log: connect error }
EOF
  systemctl enable danted && systemctl restart danted
  echo "[+] SOCKS5 服务已启动"
  echo "地址: $SERVER_IP:1080"
}
install_socks5
