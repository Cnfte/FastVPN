#!/bin/bash
function install_wireguard() {
  echo "[+] 开始安装 WireGuard..."
  # 安装依赖
  if [ -e /etc/debian_version ]; then apt update -y && apt install -y wireguard qrencode; else yum install -y epel-release && yum install -y wireguard-tools qrencode; fi
  mkdir -p /etc/wireguard && chmod 700 /etc/wireguard
  cd /etc/wireguard
  umask 077
  wg genkey | tee privatekey | wg pubkey > publickey
  cat > wg0.conf <<EOF
[Interface]
Address = 10.0.0.1/24
ListenPort = 51820
PrivateKey = $(cat privatekey)
EOF
  systemctl enable wg-quick@wg0 && systemctl start wg-quick@wg0
  echo "[+] WireGuard 已启动"
  # 生成客户端配置
  CLIENT_PRIV=$(wg genkey); CLIENT_PUB=$(echo $CLIENT_PRIV | wg pubkey)
  echo "[Interface]
PrivateKey = $CLIENT_PRIV
Address = 10.0.0.2/24
DNS = 1.1.1.1

[Peer]
PublicKey = $(cat publickey)
Endpoint = $SERVER_IP:51820
AllowedIPs = 0.0.0.0/0" > /root/wg-client.conf
  echo "[+] 客户端配置已生成: /root/wg-client.conf"
  qrencode -t terminal < /root/wg-client.conf
}
install_wireguard
