#!/bin/bash
function install_ssr() {
  echo "[+] 开始安装 ShadowsocksR..."
  git clone https://github.com/shadowsocksrr/shadowsocksr.git /opt/ssr
  cd /opt/ssr
  bash initcfg.sh
  sed -i "s/8388/8389/" user-config.json
  sed -i "s/your_password/cnfte_pass/" user-config.json
  python server.py &> /var/log/ssr.log &
  echo "[+] SSR 启动完成"
  echo "SSR 配置文件: /opt/ssr/user-config.json"
}
install_ssr
