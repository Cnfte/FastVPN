#!/bin/bash
function install_shadowsocks() {
  echo "[+] 开始安装 shadowsocks-libev..."
  if [ -e /etc/debian_version ]; then apt update -y && apt install -y shadowsocks-libev qrencode; else yum install -y epel-release && yum install -y shadowsocks-libev qrencode; fi
  cat > /etc/shadowsocks-libev/config.json <<EOF
{"server":"0.0.0.0","server_port":8388,"password":"cnfte_pass","timeout":60,"method":"aes-256-gcm"}
EOF
  systemctl enable shadowsocks-libev && systemctl restart shadowsocks-libev
  echo "[+] Shadowsocks 安装完成"
  LINK=$(echo -n "aes-256-gcm:cnfte_pass@$SERVER_IP:8388" | base64 -w 0)
  echo "链接: ss://$LINK"
  echo "二维码:"
  echo -n "ss://$LINK" | qrencode -t terminal
}
install_shadowsocks
