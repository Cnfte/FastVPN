#!/bin/bash
function install_vless() {
  echo "[+] 开始安装 Xray VLESS..."
  bash <(curl -Ls https://raw.githubusercontent.com/XTLS/Xray-install/main/install.sh)
  UUID=$(cat /proc/sys/kernel/random/uuid)
  cat > /usr/local/etc/xray/config.json <<EOF
{
  "inbounds": [{
    "port": 443,
    "protocol": "vless",
    "settings": {"clients":[{"id":"$UUID","flow":"xtls-rprx-vision"}]},
    "streamSettings":{"network":"tcp","security":"reality","realitySettings":{"show":false,"dest":"www.cloudflare.com:443","xver":0,"serverNames":["www.cloudflare.com"],"privateKey":"$(openssl rand -hex 32)","shortIds":["12ab34cd"]}}
  }],
  "outbounds":[{"protocol":"freedom"}]
}
EOF
  systemctl enable xray && systemctl restart xray
  echo "[+] VLESS 安装完成"
  echo "客户端链接:vless://$UUID@$SERVER_IP:443?security=reality&type=tcp#vless"
  echo "二维码:"
  echo -n "vless://$UUID@$SERVER_IP:443?security=reality&type=tcp#vless" | qrencode -t terminal
}
install_vless
