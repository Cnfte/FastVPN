#!/bin/bash
function install_openvpn() {
  echo "[+] 开始安装 OpenVPN..."
  bash <(curl -fsSL https://raw.githubusercontent.com/angristan/openvpn-install/master/openvpn-install.sh) <<<EOF
n
51820
n
y
EOF
  echo "[+] OpenVPN 安装完成"
  echo "客户端配置: /root/client.ovpn"
  qrencode -t terminal < /root/client.ovpn
}
install_openvpn
