#!/bin/bash
echo "[*] 防火墙开关"
STATUS=$(ufw status | grep -i inactive)
if [[ -n "$STATUS" ]]; then
  ufw enable && echo "防火墙已启用"
else
  ufw disable && echo "防火墙已关闭"
fi
