#!/bin/bash
echo "服务状态:"
for svc in wg-quick@wg0 xray openvpn shadowsocks-libev danted hysteria2; do
  systemctl is-active $svc &>/dev/null && echo "✅ $svc 运行中" || echo "❌ $svc 未运行"
done
