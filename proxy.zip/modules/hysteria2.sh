#!/bin/bash
function install_hysteria2() {
  echo "[+] 安装 Hysteria2..."
  bash <(curl -fsSL https://get.hy2.sh/)
  mkdir -p /etc/hysteria
  cat > /etc/hysteria/config.yaml <<EOF
listen: :5678
auth:
  type: password
  password: hysteria_pass
EOF
  cat > /etc/systemd/system/hysteria2.service <<EOF
[Unit]
Description=Hysteria2
After=network.target

[Service]
ExecStart=/usr/local/bin/hysteria server -c /etc/hysteria/config.yaml
Restart=on-failure

[Install]
WantedBy=multi-user.target
EOF
  systemctl daemon-reload && systemctl enable hysteria2 && systemctl start hysteria2
  echo "[+] Hysteria2 安装完成"
  echo "hy2://hysteria_pass@$SERVER_IP:5678"
  echo -n "hy2://hysteria_pass@$SERVER_IP:5678" | qrencode -t terminal
}
install_hysteria2
